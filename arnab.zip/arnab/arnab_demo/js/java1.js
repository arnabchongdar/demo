document.getElementById("w").onclick=function()
{
window.print();
}

   
